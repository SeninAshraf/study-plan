library(caTools)
library(rpart)
library(rpart.plot)

data("iris")
set.seed(123)
split<-sample.split(iris$Species,SplitRatio = 0.8)
train_data<-subset(iris,split== TRUE)
test_data<-subset(iris,split== FALSE)

model<-rpart(Species ~.,data=train_data,method="class")

prediction<-predict(model,newdata=test_data,type="class")

rpart.plot(model)
accuracy=mean(prediction==iris$Species)
cat("accuracy:",accuracy)
conf_matrix<-table(prected=prediction,Actual=test_data$Species)
print(conf_matrix)