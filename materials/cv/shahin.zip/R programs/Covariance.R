data("iris")
col1 <- tomato_df$Column1
col2 <- tomato_df$Column2
covariance <- cov(col1, col2)
cat("Covariance between Column1 and Column2:", covariance, "\n")
correlation <- cor(col1, col2)
cat("Correlation between Column1 and Column2:", correlation, "\n")