custom_min <- function(x) min(x, na.rm = TRUE)
custom_max <- function(x) max(x, na.rm = TRUE)
custom_mean <- function(x) mean(x, na.rm = TRUE)
custom_median <- function(x) median(x, na.rm = TRUE)
custom_variance <- function(x) var(x, na.rm = TRUE)
custom_sd <- function(x) sd(x, na.rm = TRUE)
custom_mode <- function(x) {
  uniq_x <- unique(x)
  uniq_x[which.max(tabulate(match(x, uniq_x)))]
}
data <- (iris)
numeric_data <- data[sapply(data, is.numeric)]
for (col in colnames(numeric_data)) {
  x <- numeric_data[[col]]
  
  if (length(x) == 0 || all(is.na(x))) {
    cat("Column:", col, "- No valid numeric data.\n\n")
  } else {
    cat("Column:", col, "\n")
    cat("Min:", custom_min(x), "\n")
    cat("Max:", custom_max(x), "\n")
    cat("Mean:", custom_mean(x), "\n")
    cat("Median:", custom_median(x), "\n")
    cat("Variance:", custom_variance(x), "\n")
    cat("Standard Deviation:", custom_sd(x), "\n")
    cat("Mode:", custom_mode(x), "\n\n")
  }
}