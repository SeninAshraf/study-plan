fib <- function(n){
  fib_series<-c(0,1)
  for(i in 3:n){
    next_term<- fib_series[i-1]+fib_series[i-2]
    fib_series <- c(fib_series,next_term)
  }
  return(fib_series)
}
result <- fib(num)
num<-as.integer(readline("Enter the num:"))
cat(result)

