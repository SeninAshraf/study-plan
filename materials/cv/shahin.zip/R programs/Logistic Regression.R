library(caTools)
titanic_data <- na.omit(read.csv("C:/Users/Senin Ashraf/Documents/R programs/titanic.csv"))

titanic_data$Sex <- as.factor(titanic_data$Sex)
titanic_data$Embarked <- as.factor(titanic_data$Embarked)
titanic_data$Survived <- as.factor(titanic_data$Survived)

set.seed(123)
split <- sample.split(titanic_data$Survived, SplitRatio = 0.8)
train_data <- droplevels(subset(titanic_data, split == TRUE))
test_data <- subset(titanic_data, split == FALSE)

log_model <- glm(Survived ~ Pclass + Sex + Age + SibSp + Parch + Fare + Embarked, 
                 data = train_data, family = binomial)

predictions <- predict(log_model, newdata = test_data, type = "response")
predicted_class <- ifelse(predictions > 0.5, 1, 0)

accuracy <- mean(predicted_class == as.numeric(as.character(test_data$Survived)))
cat("Accuracy:", accuracy, "\n")

x <- seq(-6, 6, 0.1)
plot(x, 1 / (1 + exp(-x)), type = "l", col = "black", lwd = 2,
     main = "Sigmoid Curve with Classified Data Points",
     xlab = "Logit", ylab = "Predicted Class (0 = Not Survived, 1 = Survived)")

predicted_logit <- log(predictions / (1 - predictions))
colors <- ifelse(predicted_class == 1, "red", "blue")
points(predicted_logit, predicted_class, col = colors, pch = 19)

legend("bottomright", legend = c("Survived", "Not Survived"), col = c("red", "blue"), pch = 19)