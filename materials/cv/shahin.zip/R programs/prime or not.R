n <- as.integer(readline("Enter the numer:"))

prime <- function(x){
  if(x<=1){
    return(FALSE)
  }
  for(i in 2:(x-1)){
    if(x%%2==0){
      return(FALSE)
    }
  }
  return(TRUE)
}
if(prime(n)){
  print("THE NUMBER IS PRIME")
}else{
  print("THE NUMBER IS NOT PRIME")
}