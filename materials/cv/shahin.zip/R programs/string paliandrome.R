a <- function(x) {
  s <- readline(prompt = "Enter a string:")
  x <- strsplit(s,"")[[1]]
  
  if (paste(rev(x),collapse ="") == s)
  {
   print(paste(s, "is a paliandrome")) 
  }else {
    print(paste(s, "is not a paliandrome"))
  }
}
a()
  