# Read input from the user
x <- as.integer(readline("Enter the number: "))

# Function to calculate factorial
factorial <- function(x) {
  val <- 1
  for (i in x:1) {
    val <- val * i
  }
  return(val)
}

# Call the function and print the result
result <- factorial(x)
cat("Factorial of", x, "is:", result, "\n")
