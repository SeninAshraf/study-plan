data <- read.csv("C:/Users/Senin Ashraf/Documents/R programs/TomatoFirst.csv")

mean_x <- sum(data$Color) / length(data$Color)
mean_y <- sum(data$Texture) / length(data$Texture)

cov_xy <- sum((data$Color - mean_x) * (data$Texture - mean_y)) / length(data$Color)
cat("cov bt color and texture", cov_xy ,"\n")

sd_x <- sqrt(sum((data$Color - mean_x)^2) / length(data$Color))
sd_y <- sqrt(sum((data$Texture - mean_y)^2)/ length(data$Texture))

cor_xy<- cov_xy / (sd_x * sd_y)
cat("cor bt color and texture",cor_xy,"\n")
