library(ggplot2)
df <- iris
print(colnames(df))
df <- na.omit(df[, 1:4])
set.seed(42)
model <- kmeans(df[, 1:4], centers = 3, nstart = 25)
df$cluster <- as.factor(model$cluster)
centroids <- data.frame(model$centers)
colnames(centroids) <- colnames(df[, 1:4])
print(centroids)
p <- ggplot(df, aes(x = Sepal.Length, y = Sepal.Width, color = cluster)) +
  geom_point(size = 2) +
  geom_point(data = centroids, aes(x = Sepal.Length, y = Sepal.Width), 
             shape = 19, size = 4, color = "blue") +
  ggtitle("K-Means Clustering") +
  theme_minimal()
print(p)


