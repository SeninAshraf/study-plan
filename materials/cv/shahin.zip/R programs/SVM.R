library(e1071)
library(ggplot2)
data(iris)
model <- svm(Species ~ Sepal.Length + Sepal.Width, data = iris, kernel = "linear")
x_range <- seq(min(iris$Sepal.Length) - 0.5, max(iris$Sepal.Length) + 0.5, by = 0.05)
y_range <- seq(min(iris$Sepal.Width) - 0.5, max(iris$Sepal.Width) + 0.5, by = 0.05)
grid <- expand.grid(Sepal.Length = x_range, Sepal.Width = y_range)
grid$Species <- predict(model, grid)
p <- ggplot() +
  geom_tile(data = grid, aes(x = Sepal.Length, y = Sepal.Width, fill = Species), alpha = 0.3) + 
  geom_point(data = iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species), size = 2) +
  geom_point(data = iris[model$index,], aes(x = Sepal.Length, y = Sepal.Width), color = "black", size = 3, shape = 8) +
  labs(title = "SVM Decision Boundary with Support Vectors") +
  theme_minimal()
print(p)
