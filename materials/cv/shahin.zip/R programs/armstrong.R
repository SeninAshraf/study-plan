armstrong <- function(num){
  digits <- as.numeric(strsplit(as.character(num),"")[[1]])
  n <- length(digits)
  sum <- sum(digits^n)
  
  return(sum == num)
} 

num <- as.integer(readline("Enter a number:"))
if(armstrong(num)){
  print("armstrong")
}else{
  print("not armstrong")
}