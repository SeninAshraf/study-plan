factorial <- function(x) {
  if (x == 0) return(1)
  return(prod(1:x))
}
nCr <- function(n, r) {
  return(factorial(n) / (factorial(r) * factorial(n - r)))
}
n <- as.integer(readline("Enter value of n: "))
r <- as.integer(readline("Enter value of r: "))
result <- nCr(n, r)
cat("The value of", n, "choose", r, "is:", result, "\n")