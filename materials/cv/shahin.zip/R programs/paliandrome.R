n<- as.integer(readline("Enter the number:"))
rev <- 0
num <- n

while(n>0){
  a <- n %% 10
  rev <- (rev * 10) + a
  n <- n%/% 10
}

if(rev==num){
  print(paste("Paliandrome"))
  
}else {
  print(paste("not paliandrome"))
}