library(caTools)

data <- data.frame(
  length = c(1, 2, 3, 4, 5, 6, 7),
  weight = c(6, 7, 8, 9, 12, 13, 14)
)

split <- sample.split(data$weight, SplitRatio = 0.7)
trainingset <- subset(data, split == TRUE)
testset <- subset(data, split == FALSE)

model <- lm(formula = weight ~ length, data = trainingset)

summary(model)

predicted_weight <- predict(model, newdata = testset)
print(predicted_weight)

mse <- mean(summary(model)$residuals^2)
cat("Mean Squared Error :", mse)

plot(data$length, data$weight, main = "Predicted Weight Based on Length",
     xlab = "Length", ylab = "Weight")
abline(model, col = "red", lwd = 2)