# View the first few rows of the Iris dataset
data<-(iris)

# Let's calculate covariance and correlation between 'Sepal.Length' and 'Sepal.Width'
# You can change these column names to any other columns from the Iris dataset.

# Extract the relevant columns
col1 <- iris$Sepal.Length
col2 <- iris$Sepal.Width
 v<-var(col1)
 print(v)
# Calculate Covariance
covariance <- cov(col1, col2)
cat("Covariance between Sepal.Length and Sepal.Width:", covariance, "\n")

# Calculate Correlation
correlation <- cor(col1, col2)
cat("Correlation between Sepal.Length and Sepal.Width:", correlation, "\n")
