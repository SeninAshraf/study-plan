
n <- as.integer(readline("Enter the number: "))

fact1 <- function(x) {
  if (x == 0) {
    return(1)
  } else {
    return(x * fact1(x - 1))  # Corrected to use 'x'
  }
  return(val)
}

result <- fact1(n)
cat("The factorial of", n, "is", result, "\n")
