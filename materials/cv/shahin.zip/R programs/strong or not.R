n <- as.integer(readline("Enter the number:"))
fact <- function(x){
  val <- 1
  for( i in 1:x){
    val <- val*i
  }
  return(val)
}
sum <- 0
temp <- n
while(temp > 0){
  digit = temp %% 10
  sum <- sum + fact(digit)
  temp <- temp %/% 10
}
if(sum == n){
  print("strong")
}else{
  print("not strong")
}