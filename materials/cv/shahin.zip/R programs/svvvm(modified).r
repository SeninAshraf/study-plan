library(e1071)
library(ggplot2)
library(caTools)

data(iris)

set.seed(123)
split<-sample.split(iris$Species,SplitRatio = 0.8)
train_data<-subset(iris,split==TRUE)
test_data<-subset(iris,split==FALSE)

model<-svm(Species ~ Sepal.Width+Sepal.Length,data=train_data,kernel="radial",
           gamma=0.5,
           cost=1)
prediction<-predict(model,newdata=test_data)
Accuracy<-mean(prediction==test_data$Species)
cat("Accuracy:",Accuracy)

x_range<-seq(min(iris$Sepal.Length),max(iris$Sepal.Length),length.out=200)
y_range<-seq(min(iris$Sepal.Width),max(iris$Sepal.Width),length.out=200)
grid<-expand.grid(Sepal.Length=x_range,Sepal.Width=y_range)
grid$Species<-predict(model,newdata=grid)

p<-ggplot()+
  geom_tile(data=grid,aes(x=Sepal.Length,y=Sepal.Width,fill = Species),alpha=0.3)+
  geom_point(data=train_data,aes(x = Sepal.Length, y = Sepal.Width, color = Species))+
  labs(title = "svm",x="sepal Lenth",y="sepalWidth")
print(p
      )