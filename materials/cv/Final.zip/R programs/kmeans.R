library(ggplot2)

# Load the iris dataset and remove missing values (only the first four columns)
df <- iris
df <- na.omit(df[, 1:4])

# Perform k-means clustering with 3 clusters
model <- kmeans(df[, 1:4], centers = 3, nstart = 25)

# Assign cluster values to the dataframe
df$cluster <- as.factor(model$cluster)

# Get the cluster centroids
centroids <- as.data.frame(model$centers)
print(centroids)

# Create the plot
p <- ggplot(df, aes(x = Sepal.Length, y = Sepal.Width, color = cluster)) +
  geom_point(size = 2) +  # Plot data points with different colors for each cluster
  geom_point(data = centroids, aes(x = Sepal.Length, y = Sepal.Width), shape = 19, size = 4, color = "blue") +  # Plot centroids
  ggtitle("KMEANS")  # Corrected title assignment

# Display the plot
print(p)
