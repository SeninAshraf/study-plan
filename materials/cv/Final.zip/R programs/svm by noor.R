library(e1071)
library(ggplot2)

data<-(iris)
model<-svm(Species~Sepal.Length+Sepal.Width,data=iris,kernel="linear")
x_range=seq(min(iris$Sepal.Length)-0.5,max(iris$Sepal.Length)+0.5,by =0.5)
y_range=seq(min(iris$Sepal.Width)-0.5,max(iris$Sepal.Width)+0.5,by =0.5)
grid<-expand.grid(Sepal.Length=x_range,Sepal.Width=y_range)


p<-ggplot()+
  geom_tile(data=grid,aes(x=Sepal.Length,y=Sepal.Width,fill=Species),alpha=0.3)+
  geom_point(data=iris,aes(Sepal.Length,Sepal.Width,color=Species),size=2)+
               ggtitle("SVM")+theme_minimal()
print(p)