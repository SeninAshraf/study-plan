# Load the dataset (replace 'TomatoFirst.csv' with the actual file path)
tomato_df <- read.csv("C:/Users/Senin Ashraf/Documents/R programs/iris .csv")

# Display the first few rows of the dataset to understand its structure
head(tomato_df)

# Let's assume you want to calculate covariance and correlation between two columns, say 'Column1' and 'Column2'
# Replace 'Column1' and 'Column2' with the actual column names from your dataset
col1 <- tomato_df$Column1
col2 <- tomato_df$Column2

# Calculate Covariance
covariance <- cov(col1, col2)
cat("Covariance between Column1 and Column2:", covariance, "\n")

# Calculate Correlation
correlation <- cor(col1, col2)
cat("Correlation between Column1 and Column2:", correlation, "\n")